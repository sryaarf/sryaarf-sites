# Star Rail Wars [ID]
[DAFTAR RILIS]()

## PROLOGUE

Pada Tahun 3246 Amber Era manusia mulai melakukan eksploraasi luar angkasa dan melakukan kolonisasi di berbagai bintang, bukan pesawat dengan berbagai ukuran dan bersenjata berat, melainkan kereta antar bintang yang dilengkapi dengan roda magnetik dan tabung perisai untuk melindungi Rel Antar Bintang, dan terdapat kereta keamanan sipil yang dimiliki oleh organisasi sipil yang diberi persenjataan ringan untuk memberikan ancaman kepada perompak dan digunakan untuk membersihkan jalur dari asteroit tak ber orbit yang selalu menabrak tabung perisai dan merusak komponen rel antar bintang tersebut, dan juga ada fraksi militer yang digunakan sebagai pusat keamanan dan pusat keamanan galaksi dan tidak diberikan hak untuk mengatur urusan Jalur antar bintang yang dipimpin oleh **Transgalactic Star Railways [TSR]**

Dan terdapat juga suatu Fraksi militer pertahanan yang hanya mendapatkan ke akses kendali terhadap **The Amethyst Rails** yang dimana jalur itu tidak sepanjang milik **The StoneHearts Rail**, dan Fraksi militer tersebut bernama **Rail Defense Association [RDA]**