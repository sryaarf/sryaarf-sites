# Star Rail Wars [ID]
[DAFTAR RILIS]()

## CHAPTER 1: THE SILVER RAILS MYTH

pada masa sebelum adanya **The Amethyst Rails** dan **The StoneHearts Rails** terdapat rel kuno yang sampai saat ini masih ada dan tidak pernah dilalui rute apapun, bahkan jalur jalur cabang milik The StoneHearts Rails pun tidak berani menggunakan jalur itu karena terlalu bebahaya dan tidak stabil, bahkan terlalu banyak area dimana kereta melakukan **warp jump**, tertutama di bagian rute **Planet Festival** ke **Negeri Abadi**, terdapat banyak sekali kereta hilang kontak dan tidak dapat dideteksi oleh sistem pusat miik TSR dan sudah berbaring lebih dari 1000 tahun yang lalu